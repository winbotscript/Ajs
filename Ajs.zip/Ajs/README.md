
Dkbotline

Senin, 27 Mei 2019
Cara install bot LINE di termux dan server(ssh) Sbpro-DK
Assalmu alaikum wr.wb...
Hallo guys,apa kareba buat kalian
Smoga klian Baik2 saja
Ocey langsung aja ya guys..
W akan berbagi Link github 
script selfbot Dkbot-line
Selfbot line adalah akun robot yang canggih
Fungsinya ialah!!!
- Kicker diline tapi bisa nangkis kicker dri serangan org2 jahat 
- Berbagi fitur media yg Insya allah menghibur kalian 
- Bisa tagall,juga liat sider
- bisa nambahkan admin dan staff
Tujuan nya w publikasikan script selfbot ini dgn alasan agar sc nya berkembang (AMIN)

Penasaran Silahkan anda pakai 

Dzulkifli-DK BOT PROTECT PY3 ANTI JS DK-BOT LINE
birdFIXS UPDATE:Kamis 13 DESEMBER 2018 GET TOKEN : Google Chrome
https://github.com/Dzulkiflibot/Sbpro-DK.git 
Cara Install Bot : HEADER CHROME
C9 SERVER/ VPS :
sudo apt-get update -y 
sudo apt-get install git -y 
sudo apt-get install python3-pip -y 
sudo pip3 install rsa sudo 
pip3 install thrift==0.11.0 
sudo pip3 install requests 
sudo pip3 install pytz 
sudo pip3 install bs4 
sudo pip3 install gtts 
sudo pip3 install googletrans 
sudo pip3 install humanfriendly 
sudo pip3 install goslate 
sudo pip3 install pafy 
sudo pip3 install wikipedia 
sudo pip3 install tweepy 
sudo pip3 install youtube_dl git clone https://github.com/Dzulkiflibot/Sbpro-DK.git 
Lalu
cd Sbpro-DK 
python Kifli12.py 
INSTALL Di TERMUX :
pkg update 
pkg install git 
pkg install python3-pip 
pip3 install rsa 
pip3 install thrift==0.11.0 
pip3 install requests pip3 
install bs4 pip3 install gtts 
pip3 install beautifulsoup 
pip3 install googletrans 
pip3 install pafy 
pip3 install humanfriendly 
pip3 install goslate 
pip3 install wikipedia 
pip3 install youtube_dl 
pip3 install tweepy
git clone https://github.com/Dzulkiflibot/Sbpro-DK.git 
cd Sbpro-Dk python3 kiflisb.py 
Selebih dan kurangnya moon dimaafkan,jika anda blom paham cara installnya,anggap aja itu buat tantangan buat anda ghank
Harapanku!
Jangan songong,pakailah dgan bijak,biar berkah ghank..(AMIN)....
Sistem Kerja BOT kami [Bot Protecantijs]
🔰Protect Group Rp. 100.000 / Bulan Max 200 Member
🔰Protect Event Rp. 200.000 / Bulan Max 400 Peserta
🔰Triple Protection
🔰Satu Group 2 Mod
🔰13 BOT / ROOM Sudah antijs

1. Dilarang open QR akan kena Kick
2. Dilarang membatalkan Pendingan selain Mod Auto akan kena kick oleh BOT
3. Apabila ada yang terkena Kick oleh BOT dikarenakan Open QR dan juga Membatalkan Pendingan, silahkan Undang lagi tidak terkena Banned (tapi bukan untuk dijadikan mainan)
4. Dilarang Undang orang selain Mod akan dibatalkan undangan oleh BOT
5. Dilarang Buat Note selain MOD maka akan di kick secara Auto oleh BOT (Next Update)
6. Dilarang Kick Member selain MOD maka secara Auto akan terkena Kick Oleh BOT
7. BOT akan sambut New Member saat Join
8. Dilarang ubah Logo Room Kcuali admin bot akan kembalikan logo nya smula dan kick member yg lancang ubah logo room
9. Dilarang ubah nama room,bot akan mengembalikan nama room dan kick member yg lancang kcuali admin bot
Bonus FUN Command untuk MOD
10.Bot akan invite kmbali admin ketika kicker menghapus admin dan staff ke room
11.Ditambah banyak fitur2 menarik sprtih mp3,mp4 dll

Catatan Penting !
Moderator dilarang undang BOT kami selain Room yang sudah di Setting... dan ditentukan.
Apabila melanggar kami akan Cabut Kontrak dan juga bisa ambil tindakan lebih dari itu, karena itu sama saja sudah mau merusak dan mengkhianati kepercayaan yang sudah kami berikan...

🔰Jual TOKEN PRIMARY
Rp. 100.000 / 20 ACOUNT
Rp. 200.000 / 40 ACOUNT

🔰🔰Bisnis OWNER DKBOT

Cabang Terbatas

Rp. 400.000 / Bulan
🔰 Mendapatkan 9 BOT
🔰 Jatah 10 Room
🔰 Triple Server (tidak pernah down)
🔰 Bisa Request Nama BOT 1
🔰 Bisa Kendalikan BOT sendiri
🔰 Bisa Disewakan lagi untuk Protect Room
🔰 Tetap dalam pantauan kami dari Server
🔰 Tidak untuk dijadikan Ajang Battle BOT atau War BOT
🔰 Tidak untuk menyerang Room orang lain
🔰 Apabila melanggar ketentuan akan kami Expel

🔰Bisnis Siri BOT :
🔰Paket 500rb : 10 Ticket = 20 Room
🔰Paket 1 Juta : 20 Ticket = 40 Room
🔰Paket 2 Juta : 40 Ticket = 80 Room

#Bisa pasang siri sendiri

🔰Menerima Setting SELF BOT yaitu ID kalian bisa menjadi BOT dan mendapatkan 2 BOT Kicker, Harga Rp.400.000 / Bulan
- Bisa Check Gid / Mid
- Anti Spam / Refused Invitation
- Bisa Nuker Room [Nuklir]
- Bisa Cek CCTV / Sider / Lurkers
- Bisa Protect Staff
- Bisa Setting Staff: on
- Bisa Pecat / Expel Staff
- Apabila Self Bot di kick, maka Kicker akan kick orang tersebut, dan mengundang kembali Selfbot, begitupun untuk Staff yang di Setting

Untuk Info & Pemesanan
🔰CUSTOMER SERVICE :
ID LINE : dkbots
WA : 082197839026

🔹ID LINE SEKARANG :
🔰OWNER DKBOTS🔰
https://line.me/R/ti/p/~dkbots

🔹WATSAPP
082197839026

🔹YOUTUBE
https://youtu.be/t-fkNR0d_WM
PM saya Bisa DIUJI langsung BUKTI bukan JANJI👍

🔹 Join Squary Klik
[DKBOT] Anda diundang ke obrolan "DKBOT".
https://line.me/ti/g2/O_Gk81Z_DcCk-rcUz-GpUQ
i'm happy 's to meet youo


Keep spirit fort 's to day
Salam dari team DKBOT-LINE
Dan apabila minat gabung ngumpul di sq silahkan add contact line = dzul1991ji
Wa.08219783902
Thank's
           Wassalam...
Dzulkiflidkbot di 08.09
Berbagi
Tidak ada komentar:
Posting Komentar
Beranda
Lihat versi web
Mengenai Saya
Dzulkiflidkbot
 
Diberdayakan oleh Blogger.
By.Dzulkiflii Makassar
